document.getElementById("calcular").addEventListener("click", () => {
  const dataRetirada = new Date(document.getElementById("data-retirada").value);
  const dataPrevista = new Date(document.getElementById("data-prevista").value);
  const dataDevolvida = new Date(document.getElementById("data-devolvida").value);

  if (isNaN(dataRetirada) || isNaN(dataPrevista) || isNaN(dataDevolvida)) {
    document.getElementById("resultado").innerText = "Por favor, preencha todas as datas corretamente.";
    return;
  }

  const atraso = Math.max(0, (dataDevolvida - dataPrevista) / (1000 * 60 * 60 * 24));
  const limiteSuspensao = 90; // 90 dias como limite máximo
  const diasSuspensao = Math.min(atraso, limiteSuspensao);

  const dataSuspensao = new Date(dataDevolvida);
  dataSuspensao.setDate(dataSuspensao.getDate() + diasSuspensao);

  document.getElementById("resultado").innerHTML = `
    <p>Atraso: <strong>${atraso} dia(s)</strong></p>
    <p>Suspenso até: <strong>${dataSuspensao.toLocaleDateString()}</strong></p>
  `;
});
